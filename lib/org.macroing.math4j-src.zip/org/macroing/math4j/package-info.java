/**
 * Provides the core APIs of Math4J.
 */
package org.macroing.math4j;